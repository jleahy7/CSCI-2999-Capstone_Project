/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package everhealthmanager;

//Import Statements
import java.io.IOException;
import java.net.URL;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * Controller class for FXMLDocument
 * @author Jacob Wagner
 */
public class FXMLDocumentController implements Initializable {
    @FXML
    private TextField Id_box;
    @FXML
    private TextField password_box;
    @FXML
    private Label invalidLabel;
    @FXML
    /**
     * If login credentials are accepted, transitions to the Employee log in screen
     * @Exception throws IOException if new scene is not found
     */
    private void handleSignInButtonAction(ActionEvent event) throws IOException {
             
        
        //If login is successful go to the Employee Homepage
        Parent home_page_parent = FXMLLoader.load(getClass().getResource("EmployeeHomepage.fxml"));
        Scene home_page_scene = new Scene(home_page_parent);
        Stage app_stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
        
        //get data from username and password fields
        if(isValid())
        {
            app_stage.hide();
            app_stage.setScene(home_page_scene);
            app_stage.show();
        }
        else
        {
            Id_box.clear();
            password_box.clear();
            invalidLabel.setText("The ID or Password is incorrect");
        }
    }
    
    @FXML
    /**
     * Exits the program when clicked
     */
    private void handleCancelButtonAction(ActionEvent event) {
        System.out.println("You closed me!");
        System.exit(0);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    private boolean isValid()
    {
      boolean accepted = false;
      Connection conn = null;
      java.sql.Statement stmt = null;
      try 
      {
            conn = SqlConnection.DBconnect();
            conn.setAutoCommit(false);
            
            System.out.println("Connection Successful");
            System.out.println("SELECT * FROM member WHERE firstname= " + "'" + Id_box.getText() + "'" + " AND password= " + "'" + password_box.getText() + "'");

            stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM member WHERE firstname= " + "'" + Id_box.getText() + "'" + " AND password= " + "'" + password_box.getText() + "'");

            while(rs.next())
            {
                if (rs.getString("firstname") != null && rs.getString("password") != null)
                {
                    accepted = true;
                }
            }
            rs.close();
            stmt.close();
            conn.close();
       
      }catch(SQLException e)
      {
          System.out.println("Error");
      }
      
      return accepted;
      
    }
    

    
    
    
}
